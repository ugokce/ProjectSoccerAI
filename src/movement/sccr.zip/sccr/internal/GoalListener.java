package arhrs.movement.sccr.internal;

public interface GoalListener {
    void goalScored(int team);
}
