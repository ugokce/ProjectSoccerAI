package arhrs.movement.sccr.internal;

import live.movement.Renderable;
import live.movement.StaticInfo;
import org.newdawn.slick.Color;
import org.newdawn.slick.Font;
import org.newdawn.slick.Graphics;

public class ScoreBoardImage implements Renderable {


    public static final float ScoreBoardCellWidth = 15;
    public static final float ScoreBoardCellHeight = 20;
    public static final Color ScoreBoardColor = Color.white;
    public static final float ScoreBoardMargin = 2;
    ScoreBoard scoreBoard;


    public void setScoreBoard(ScoreBoard scoreBoard) {
        this.scoreBoard = scoreBoard;
    }
    @Override
    public void render(Graphics g, StaticInfo pos) {
        g.setColor(SimpleSoccerPlayer.PlayerColors[0]);

        g.fillRect((float) pos.getPos().x(),(float) pos.getPos().y(),ScoreBoardCellWidth,ScoreBoardCellHeight);
        g.setColor(SimpleSoccerPlayer.PlayerColors[1]);
        g.fillRect((float) pos.getPos().x()+ScoreBoardCellWidth,(float) pos.getPos().y(),ScoreBoardCellWidth,ScoreBoardCellHeight);

        g.setColor(ScoreBoardColor);
        g.drawRect((float) pos.getPos().x(),(float) pos.getPos().y(),ScoreBoardCellWidth,ScoreBoardCellHeight);
        g.drawRect((float) pos.getPos().x()+ScoreBoardCellWidth,(float) pos.getPos().y(),ScoreBoardCellWidth,ScoreBoardCellHeight);


        g.drawString(""+scoreBoard.getScore(0),(float) pos.getPos().x()+ScoreBoardMargin, (float)pos.getPos().y()+ScoreBoardMargin);
        g.drawString(""+scoreBoard.getScore(1),(float) pos.getPos().x()+ScoreBoardCellWidth+ScoreBoardMargin, (float)pos.getPos().y()+ScoreBoardMargin);
    }
}
